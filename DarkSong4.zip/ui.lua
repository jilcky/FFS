function draw()
	-- You can draw things here with draw_ functions
	-- draw_text(10, 10, "Hello!");
end