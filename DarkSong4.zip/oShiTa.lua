function step(self, other)


	action_inherited();


	--控制

	self.jumpHeight =5.5*0.68
end
